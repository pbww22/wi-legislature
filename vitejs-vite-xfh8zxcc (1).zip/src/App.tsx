import { useState } from 'react';

const data = [
  {
    "name": "Julian Bradley",
    "chamber": "Senate",
    "party": "Republican",
    "office": "316 South",
    "phone": "5400-06-01 00:00:00",
    "email": "Sen.Bradley@legis.wisconsin.gov",
    "staff": "Brett Healy, Zacharias Olstinske, Nik Rettinger, Jeff Schultz",
    "committees": []
  },
  {
    "name": "Rachael Cabral-Guevara",
    "chamber": "Senate",
    "party": "Republican",
    "office": "323 South",
    "phone": "6-0718",
    "email": "Sen.Cabral-Guevara@legis.wisconsin.gov",
    "staff": "Ryan Retza, Sydney Rose Faestel, Christian Gonzalez-Caraballo, Michael Moscicke",
    "committees": []
  },
  {
    "name": "Tim Carpenter",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "104 South",
    "phone": "8535-06-01 00:00:00",
    "email": "Sen.Carpenter@legis.wisconsin.gov",
    "staff": "Will Swassing, Russell DeLong, Colin Barushok",
    "committees": []
  },
  {
    "name": "Kristin Dassler-Alfheim",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "106 South",
    "phone": "7513-06-01 00:00:00",
    "email": "Sen.Dassler-Alfheim@legis.wisconsin.gov",
    "staff": "Kathy Divine, Eli Jaskowiak, Keara Wood",
    "committees": []
  },
  {
    "name": "Dora Drake",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "126 South",
    "phone": "5810-06-01 00:00:00",
    "email": "Sen.Drake@legis.wisconsin.gov",
    "staff": "Ryan Schroeder, Amanda Puccini",
    "committees": []
  },
  {
    "name": "Mary Felzkowski",
    "chamber": "Senate",
    "party": "Republican",
    "office": "220 South",
    "phone": "2509-06-01 00:00:00",
    "email": "Sen.Felzkowski@legis.wisconsin.gov",
    "staff": "Dustin Truax, Cameil Bowler, Gabriella Cacciotti, Christopher Seitz, John Soper, David Specht-Boardman",
    "committees": []
  },
  {
    "name": "Dan Feyen",
    "chamber": "Senate",
    "party": "Republican",
    "office": "306 South",
    "phone": "5300-06-01 00:00:00",
    "email": "Sen.Feyen@legis.wi.gov",
    "staff": "Tim Lakin, John Beauchamp, Matthias Censky",
    "committees": []
  },
  {
    "name": "Jodi Habush Sinykin",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "19 South",
    "phone": "5830-06-01 00:00:00",
    "email": "Sen.HabushSinykin@legis.wisconsin.gov",
    "staff": "Robert Abrahamian, Amanda Kind, Eva Wahlstrom",
    "committees": []
  },
  {
    "name": "Dianne Hesselbein",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "206 South",
    "phone": "6670-06-01 00:00:00",
    "email": "Sen.Hesselbein@legis.wisconsin.gov",
    "staff": "Ryan Knocke, Denise Stromme, Margie Berkowitz, Geoff Gaston, Megan Greenstein, Chandra Munroe, Laura Pratt , Jose Rodriguez, Jeanne Weiss",
    "committees": []
  },
  {
    "name": "Rob Hutton",
    "chamber": "Senate",
    "party": "Republican",
    "office": "313 South",
    "phone": "2512-06-01 00:00:00",
    "email": "Sen.Hutton@legis.wisconsin.gov",
    "staff": "Sandy Lonegran, Edward Eberle, Patrick Kanarowski, Chris Rochester",
    "committees": []
  },
  {
    "name": "Andre Jacque",
    "chamber": "Senate",
    "party": "Republican",
    "office": "7 South",
    "phone": "3512-06-01 00:00:00",
    "email": "Sen.Jacque@legis.wisconsin.gov",
    "staff": "Bill Cosh, Nicolas Cravillion, Malik Staude, Matthew Tompach",
    "committees": []
  },
  {
    "name": "John Jagler",
    "chamber": "Senate",
    "party": "Republican",
    "office": "415 South",
    "phone": "5660-06-01 00:00:00",
    "email": "Sen.Jagler@legis.wisconsin.gov",
    "staff": "David Fladeboe, Charlie Bellin, Sarah Gibbs, Matthew VanRemortel",
    "committees": []
  },
  {
    "name": "Jesse James",
    "chamber": "Senate",
    "party": "Republican",
    "office": "319 South",
    "phone": "7511-06-01 00:00:00",
    "email": "Sen.James@legis.wisconsin.gov",
    "staff": "Victoria Casola, Nathan Cera, Kara Sagan",
    "committees": []
  },
  {
    "name": "LaTonya Johnson",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "131 South",
    "phone": "2500-06-01 00:00:00",
    "email": "Sen.Johnson@legis.wisconsin.gov",
    "staff": "Lacy Fox, Shannon McCoy, Casey Steinau, Jacob Taylor",
    "committees": []
  },
  {
    "name": "Chris Kapenga",
    "chamber": "Senate",
    "party": "Republican",
    "office": "118 South",
    "phone": "9174-06-01 00:00:00",
    "email": "Sen.Kapenga@legis.wisconsin.gov",
    "staff": "Jennifer Esser, Hope Certalic, Michael Neuwohner, Denise Richter",
    "committees": []
  },
  {
    "name": "Sarah Keyeski",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "22 South",
    "phone": "6-0751",
    "email": "Sen.Keyeski@legis.wisconsin.gov",
    "staff": "Sarah Semrad, Kylie Coffin, Ethan Vanermause",
    "committees": []
  },
  {
    "name": "Chris Larson",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "18 South",
    "phone": "7505-06-01 00:00:00",
    "email": "Sen.Larson@legis.wisconsin.gov",
    "staff": "Justin Sargent, Justin Bielinski, Nick Janis",
    "committees": []
  },
  {
    "name": "Devin LeMahieu",
    "chamber": "Senate",
    "party": "Republican",
    "office": "211 South",
    "phone": "2056-06-01 00:00:00",
    "email": "Sen.LeMahieu@legis.wisconsin.gov",
    "staff": "Ashley Czaja, Johnny Humphrey, Colin Nygren, Leah Peterson, Brian Radday, Bethany Rasmussen, Amanda Truax",
    "committees": []
  },
  {
    "name": "Howard Marklein",
    "chamber": "Senate",
    "party": "Republican",
    "office": "316 East",
    "phone": "6-0703",
    "email": "Sen.Marklein@legis.wi.gov",
    "staff": "Peter Hienz, Connor Buss, Samantha Marshall, Eileen O'Neill, Vincent Williams",
    "committees": []
  },
  {
    "name": "Steve Nass",
    "chamber": "Senate",
    "party": "Republican",
    "office": "10 South",
    "phone": "2635-06-01 00:00:00",
    "email": "Sen.Nass@legis.wisconsin.gov",
    "staff": "Mike Mikalsen, Nathan Cobb, Adam Field",
    "committees": []
  },
  {
    "name": "Brad Pfaff",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "20 South",
    "phone": "5490-06-01 00:00:00",
    "email": "Sen.Pfaff@legis.wisconsin.gov",
    "staff": "Dave Groshek, Benjamin O'Connell, Christian Ullsvik",
    "committees": []
  },
  {
    "name": "Romaine Quinn",
    "chamber": "Senate",
    "party": "Republican",
    "office": "123 South",
    "phone": "3510-06-01 00:00:00",
    "email": "Sen.Quinn@legis.wisconsin.gov",
    "staff": "Jason Vick, Ericka Braatz, Jack Fitzgerald, Stacey Hessel",
    "committees": []
  },
  {
    "name": "Melissa Ratcliff",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "5 South",
    "phone": "9170-06-01 00:00:00",
    "email": "Sen.Ratcliff@legis.wisconsin.gov",
    "staff": "Ben Gebhart, Isko Lee-Dralle, Melissa Mulliken",
    "committees": []
  },
  {
    "name": "Kelda Roys",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "130 South",
    "phone": "6-1627",
    "email": "Sen.Roys@legis.wisconsin.gov",
    "staff": "George Gillis, Emily Duernberger, Jalen Knuteson, Carla Wolff",
    "committees": []
  },
  {
    "name": "Jeff Smith",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "109 South",
    "phone": "8546-06-01 00:00:00",
    "email": "Sen.Smith@legis.wisconsin.gov",
    "staff": "Beau Stafford, Avrie Marsolek, Christian Plata, Joseph Splinter",
    "committees": []
  },
  {
    "name": "Mark Spreitzer",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "108 South",
    "phone": "2253-06-01 00:00:00",
    "email": "Sen.Spreitzer@legis.wisconsin.gov",
    "staff": "Doug Hyant, Katherine Illiff, Dylan Moffitt, Eleanor Thornman",
    "committees": []
  },
  {
    "name": "Rob Stafsholt",
    "chamber": "Senate",
    "party": "Republican",
    "office": "15 South",
    "phone": "7745-06-01 00:00:00",
    "email": "Sen.Stafsholt@legis.wisconsin.gov",
    "staff": "Sharlene Konkel, Trevor Woyda",
    "committees": []
  },
  {
    "name": "Patrick Testin",
    "chamber": "Senate",
    "party": "Republican",
    "office": "8 South",
    "phone": "3123-06-01 00:00:00",
    "email": "Sen.Testin@legis.wisconsin.gov",
    "staff": "James Emerson, Christina Nelson, Adam Tobias, Andrew Trenta",
    "committees": []
  },
  {
    "name": "Cory Tomczyk",
    "chamber": "Senate",
    "party": "Republican",
    "office": "310 South",
    "phone": "2502-06-01 00:00:00",
    "email": "Sen.Tomczyk@legis.wisconsin.gov",
    "staff": "Mitch Sands, Timmy Gomez, Adam Peterson, Chad Taylor",
    "committees": []
  },
  {
    "name": "Jamie Wall",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "3 South",
    "phone": "6-0484",
    "email": "Sen.Wall@legis.wisconsin.gov",
    "staff": "Sarah Barry, Madeleine Buchholz-Kneeland, Kate Thickens",
    "committees": []
  },
  {
    "name": "Van Wanggaard",
    "chamber": "Senate",
    "party": "Republican",
    "office": "122 South",
    "phone": "6-1832",
    "email": "Sen.Wanggaard@legis.wisconsin.gov",
    "staff": "Scott Kelly, Eric Barbour, Michelle Osdene",
    "committees": []
  },
  {
    "name": "Eric Wimberger",
    "chamber": "Senate",
    "party": "Republican",
    "office": "409 South",
    "phone": "5670-06-01 00:00:00",
    "email": "Sen.Wimberger@legis.wisconsin.gov",
    "staff": "Zachary Stollfus, Bill Kloiber, Alex Richter, Blake Weiner",
    "committees": []
  },
  {
    "name": "Robert Wirch",
    "chamber": "Senate",
    "party": "Democrat",
    "office": "127 South",
    "phone": "8979-07-01 00:00:00",
    "email": "Sen.Wirch@legis.wisconsin.gov",
    "staff": "Paula McGuire, Matt Archambo, Henry Pitsch",
    "committees": []
  },
  {
    "name": " ",
    "chamber": "Senate",
    "party": NaN,
    "office": NaN,
    "phone": "nan",
    "email": "",
    "staff": "",
    "committees": []
  },
  {
    "name": " ",
    "chamber": "Senate",
    "party": NaN,
    "office": NaN,
    "phone": "nan",
    "email": "",
    "staff": "",
    "committees": []
  },
  {
    "name": "Scott Allen",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "105 West",
    "phone": "9182-07-01 00:00:00",
    "email": "Rep.Allen@legis.wisconsin.gov",
    "staff": "Michael McKittrick",
    "committees": []
  },
  {
    "name": "Clinton Anderson",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "17 North",
    "phone": "9145-07-01 00:00:00",
    "email": "Rep.CAnderson@legis.wisconsin.gov",
    "staff": "McKinley Falkowski, Jim White",
    "committees": []
  },
  {
    "name": "Deb Andraca",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "109 North",
    "phone": "9123-07-01 00:00:00",
    "email": "Rep.Andraca@legis.wisconsin.gov",
    "staff": "Stacy Benoy , Fred Ludwig",
    "committees": []
  },
  {
    "name": "David Armstrong",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "220 North",
    "phone": "9167-07-01 00:00:00",
    "email": "Rep.Armstrong@legis.wisconsin.gov",
    "staff": "Matt Pulda, Tanner Schafer",
    "committees": []
  },
  {
    "name": "Margaret Arney",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "303 West",
    "phone": "9118-07-01 00:00:00",
    "email": "Rep.Arney@legis.wisconsin.gov",
    "staff": "Chris Stoa",
    "committees": []
  },
  {
    "name": "Tyler August",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "115 West",
    "phone": "9131-07-01 00:00:00",
    "email": "Rep.August@legis.wisconsin.gov",
    "staff": "Luke Bacher, Ariano Beno, Cameron O'Connell, Jason Rostan",
    "committees": []
  },
  {
    "name": "Mike Bare",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "306 West",
    "phone": "9180-07-01 00:00:00",
    "email": "Rep.Bare@legis.wisconsin.gov",
    "staff": "McKinley Falkowski, William Oemichen",
    "committees": []
  },
  {
    "name": "Elijah Behnke",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "219 North",
    "phone": "9106-07-01 00:00:00",
    "email": "Rep.Behnke@legis.wisconsin.gov",
    "staff": "Seth Allen, Bradley Petersen",
    "committees": []
  },
  {
    "name": "Jill Billings",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "118 North",
    "phone": "9195-07-01 00:00:00",
    "email": "Rep.Billings@legis.wisconsin.gov",
    "staff": "Marissa Howe, Lauren Yoder",
    "committees": []
  },
  {
    "name": "Mark Born",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "308 East",
    "phone": "9137-07-01 00:00:00",
    "email": "Rep.Born@legis.wisconsin.gov",
    "staff": "Gianna Feest, Anna Knocke, Nick Krueger, Storm Linjer, Joe Malkasian, Cassidy Sommer",
    "committees": []
  },
  {
    "name": "Lindee Brill",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "409 North",
    "phone": "9127-07-01 00:00:00",
    "email": "Rep.Brill@legis.wisconsin.gov",
    "staff": "Kyle Mackey",
    "committees": []
  },
  {
    "name": "Robert Brooks",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "216 North",
    "phone": "9159-07-01 00:00:00",
    "email": "Rep.Rob.Brooks@legis.wisconsin.gov",
    "staff": "Claire Bradley, Christopher Schaefer",
    "committees": []
  },
  {
    "name": "Brienne Brown",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "9 North",
    "phone": "9143-07-01 00:00:00",
    "email": "Rep.Brown@legis.wisconsin.gov",
    "staff": "Tayler Palkowski",
    "committees": []
  },
  {
    "name": "Calvin Callahan",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "127 West",
    "phone": "9135-07-01 00:00:00",
    "email": "Rep.Callahan@legis.wisconsin.gov",
    "staff": "Wyatt Cooper, AmyRose Murphy",
    "committees": []
  },
  {
    "name": "Ryan Clancy",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "21 North",
    "phone": "9119-07-01 00:00:00",
    "email": "Rep.Clancy@legis.wisconsin.gov",
    "staff": "Amelia Berendt, Timothy Schaefer",
    "committees": []
  },
  {
    "name": "Angelina Cruz",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "111 North",
    "phone": "9162-07-01 00:00:00",
    "email": "Rep.Cruz@legis.wisconsin.gov",
    "staff": "Nolan Anderson",
    "committees": []
  },
  {
    "name": "Alex Dallman",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "320 East",
    "phone": "9139-07-01 00:00:00",
    "email": "Rep.Dallman@legis.wisconsin.gov",
    "staff": "Ryan Ring",
    "committees": []
  },
  {
    "name": "Karen DeSanto",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "7 West",
    "phone": "9140-07-01 00:00:00",
    "email": "Rep.DeSanto@legis.wisconsin.gov",
    "staff": "Lauren Damgaard",
    "committees": []
  },
  {
    "name": "Ben DeSmidt",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "18 North",
    "phone": "9165-07-01 00:00:00",
    "email": "Rep.DeSmidt@legis.wisconsin.gov",
    "staff": "Baily Remiker",
    "committees": []
  },
  {
    "name": "Barbara Dittrich",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "317 North",
    "phone": "9199-07-01 00:00:00",
    "email": "Rep.Dittrich@legis.wisconsin.gov",
    "staff": "Marshall Bergman, Nicholas Zabloudil",
    "committees": []
  },
  {
    "name": "Bob Donovan",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "3 North",
    "phone": "9161-07-01 00:00:00",
    "email": "Rep.Donovan@legis.wisconsin.gov",
    "staff": "Stephan Gieschen, Dan Posca",
    "committees": []
  },
  {
    "name": "Steve Doyle",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "124 North",
    "phone": "9194-07-01 00:00:00",
    "email": "Rep.Doyle@legis.wisconsin.gov",
    "staff": "James Macken, Stephen Pienkos",
    "committees": []
  },
  {
    "name": "Cindi Duchow",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "210 North",
    "phone": "9197-07-01 00:00:00",
    "email": "Rep.Duchow@legis.wisconsin.gov",
    "staff": "Samantha Mayer, Colin Weeks",
    "committees": []
  },
  {
    "name": "Jodi Emerson",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "322 West",
    "phone": "9191-07-01 00:00:00",
    "email": "Rep.Emerson@legis.wisconsin.gov",
    "staff": "Dylan Green, Crystal Miller",
    "committees": []
  },
  {
    "name": "Joan Fitzgerald",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "11 West",
    "phone": "9146-07-01 00:00:00",
    "email": "Rep.Fitzgerald@legis.wisconsin.gov",
    "staff": "Katherine Morgan",
    "committees": []
  },
  {
    "name": "Benjamin Franklin",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "304 North",
    "phone": "9188-07-01 00:00:00",
    "email": "Rep.Franklin@legis.wisconsin.gov",
    "staff": "Nolen Gutgesell",
    "committees": []
  },
  {
    "name": "Joy Goeben",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "209 North",
    "phone": "9105-07-01 00:00:00",
    "email": "Rep.Goeben@legis.wisconsin.gov",
    "staff": "Meagan Matthews, Antonio Patz",
    "committees": []
  },
  {
    "name": "Russell Goodwin",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "8 North",
    "phone": "9112-07-01 00:00:00",
    "email": "Rep.Goodwin@legis.wisconsin.gov",
    "staff": "Martha Collins",
    "committees": []
  },
  {
    "name": "Chanz Green",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "125 West",
    "phone": "9174-07-01 00:00:00",
    "email": "Rep.Green@legis.wisconsin.gov",
    "staff": "Carson Lee",
    "committees": []
  },
  {
    "name": "Rick Gundrum",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "312 North",
    "phone": "9158-07-01 00:00:00",
    "email": "Rep.Gundrum@legis.wisconsin.gov",
    "staff": "Christian Lubke, Gus Pirlot",
    "committees": []
  },
  {
    "name": "Nate Gustafson",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "316 North",
    "phone": "9155-07-01 00:00:00",
    "email": "Rep.Gustafson@legis.wisconsin.gov",
    "staff": "Sammy Nelson",
    "committees": []
  },
  {
    "name": "Kalan Haywood",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "119 North",
    "phone": "9116-07-01 00:00:00",
    "email": "Rep.Haywood@legis.wisconsin.gov",
    "staff": "Isaia Ben-Ami, Adrian Catacutan, Sydnee Matthew",
    "committees": []
  },
  {
    "name": "Francesca Hong",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "122 North",
    "phone": "9176-07-01 00:00:00",
    "email": "Rep.Hong@legis.wisconsin.gov",
    "staff": "Nada Elmikashfi, Reuben Berkowitz",
    "committees": []
  },
  {
    "name": "Karen Hurd",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "321 East",
    "phone": "9169-07-01 00:00:00",
    "email": "Rep.Hurd@legis.wisconsin.gov",
    "staff": "Tyler Longsine, Jon Minneci",
    "committees": []
  },
  {
    "name": "Andrew Hysell",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "304 West",
    "phone": "9148-07-01 00:00:00",
    "email": "Rep.Hysell@legis.wisconsin.gov",
    "staff": "Kyra McKeska",
    "committees": []
  },
  {
    "name": "Jenna Jacobson",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "128 North",
    "phone": "9150-07-01 00:00:00",
    "email": "Rep.Jacobson@legis.wisconsin.gov",
    "staff": "Amanda Peterson, Stephen Pienkos",
    "committees": []
  },
  {
    "name": "Brent Jacobson",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "420 North",
    "phone": "9187-07-01 00:00:00",
    "email": "Rep.Brent.Jacobson@legis.wisconsin.gov",
    "staff": "Alekzander Timmerman",
    "committees": []
  },
  {
    "name": "Alex Joers",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "107 North",
    "phone": "9181-07-01 00:00:00",
    "email": "Rep.Joers@legis.wisconsin.gov",
    "staff": "Sophie Coronelli",
    "committees": []
  },
  {
    "name": "Tara Johnson",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "8 West",
    "phone": "9196-07-01 00:00:00",
    "email": "Rep.Johnson@legis.wisconsin.gov",
    "staff": "Jonathan Good",
    "committees": []
  },
  {
    "name": "Dean Kaufert",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "223 North",
    "phone": "9153-07-01 00:00:00",
    "email": "Rep.Kaufert@legis.wisconsin.gov",
    "staff": "",
    "committees": []
  },
  {
    "name": "Karen Kirsch",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "15 West",
    "phone": "9107-07-01 00:00:00",
    "email": "Rep.Kirsch@legis.wisconsin.gov",
    "staff": "Matthew Mareno",
    "committees": []
  },
  {
    "name": "Joel Kitchens",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "314 North",
    "phone": "9101-07-01 00:00:00",
    "email": "Rep.Kitchens@legis.wisconsin.gov",
    "staff": "Bob Delaporte, Marco Lopez",
    "committees": []
  },
  {
    "name": "Daniel Knodl",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "221 North",
    "phone": "9124-07-01 00:00:00",
    "email": "Rep.Knodl@legis.wisconsin.gov",
    "staff": "Danielle Rogers",
    "committees": []
  },
  {
    "name": "Robert Kreibich",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "107 West",
    "phone": "9128-07-01 00:00:00",
    "email": "Rep.Kreibich@legis.wisconsin.gov",
    "staff": "Faith Alpaugh",
    "committees": []
  },
  {
    "name": "Scott Krug",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "315 North",
    "phone": "9172-07-01 00:00:00",
    "email": "Rep.Krug@legis.wisconsin.gov",
    "staff": "Mary Curry, Trevor Ford, Maryna Oliinyk",
    "committees": []
  },
  {
    "name": "Tony Kurtz",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "304 East",
    "phone": "9141-07-01 00:00:00",
    "email": "Rep.Kurtz@legis.wisconsin.gov",
    "staff": "Jason Knack, Danielle Zimmerman",
    "committees": []
  },
  {
    "name": "Darrin Madison",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "21 North",
    "phone": "9110-07-01 00:00:00",
    "email": "Rep.Madison@legis.wisconsin.gov",
    "staff": "David O'Keeffe, Timothy Schaefer",
    "committees": []
  },
  {
    "name": "Dave Maxey",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "4 West",
    "phone": "9183-07-01 00:00:00",
    "email": "Rep.Maxey@legis.wisconsin.gov",
    "staff": "Connor Hartje, Jason Stapelmann",
    "committees": []
  },
  {
    "name": "Renuka Mayadev",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "10 West",
    "phone": "9177-07-01 00:00:00",
    "email": "Rep.Mayadev@legis.wisconsin.gov",
    "staff": "Austen Wallenfang",
    "committees": []
  },
  {
    "name": "Maureen McCarville",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "11 North",
    "phone": "9142-07-01 00:00:00",
    "email": "Rep.McCarville@legis.wisconsin.gov",
    "staff": "Amy Snyder-Heitman",
    "committees": []
  },
  {
    "name": "Tip McGuire",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "321 West",
    "phone": "9164-07-01 00:00:00",
    "email": "Rep.McGuire@legis.wisconsin.gov",
    "staff": "Dan Housh , Quinn Marita",
    "committees": []
  },
  {
    "name": "Paul Melotik",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "308 North",
    "phone": "9122-07-01 00:00:00",
    "email": "Rep.Melotik@legis.wisconsin.gov",
    "staff": "Nathan Anfinson, Andres Prado",
    "committees": []
  },
  {
    "name": "Vincent Miresse",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "112 North",
    "phone": "9171-07-01 00:00:00",
    "email": "Rep.Miresse@legis.wisconsin.gov",
    "staff": "Ben Pilon",
    "committees": []
  },
  {
    "name": "Supreme Moore Omokunde",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "6 North",
    "phone": "9117-07-01 00:00:00",
    "email": "Rep.MooreOmokunde@legis.wisconsin.gov",
    "staff": "Will Zolecki, Inez Mendez",
    "committees": []
  },
  {
    "name": "Clint Moses",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "12 West",
    "phone": "9192-07-01 00:00:00",
    "email": "Rep.Moses@legis.wisconsin.gov",
    "staff": "Maryjane Behm",
    "committees": []
  },
  {
    "name": "David Murphy",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "318 North",
    "phone": "9156-07-01 00:00:00",
    "email": "Rep.Murphy@legis.wisconsin.gov",
    "staff": "Steve Knudson, Mike Pexa",
    "committees": []
  },
  {
    "name": "Jeffrey Mursau",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "113 West",
    "phone": "9136-07-01 00:00:00",
    "email": "Rep.Mursau@legis.wisconsin.gov",
    "staff": "Cory Bruce",
    "committees": []
  },
  {
    "name": "Amanda Nedweski",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "208 North",
    "phone": "9132-07-01 00:00:00",
    "email": "Rep.Nedweski@legis.wisconsin.gov",
    "staff": "Eric Brooks, Tami Rongstad",
    "committees": []
  },
  {
    "name": "Greta Neubauer",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "201 West",
    "phone": "9166-07-01 00:00:00",
    "email": "Rep.Neubauer@legis.wisconsin.gov",
    "staff": "Sidney Litke, Kyle Sandow, Julie Benkoske, Milly Miechadesh, Scott Templeton, Sam Voorhees, Adam Wigger",
    "committees": []
  },
  {
    "name": "Adam Neylon",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "204 North",
    "phone": "9115-07-01 00:00:00",
    "email": "Rep.Neylon@legis.wisconsin.gov",
    "staff": "Dillon McGee, Joe Zapf",
    "committees": []
  },
  {
    "name": "Todd Novak",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "310 North",
    "phone": "9151-07-01 00:00:00",
    "email": "Rep.Novak@legis.wisconsin.gov",
    "staff": "Sam Kussow, Morgan O'Flahrity",
    "committees": []
  },
  {
    "name": "Jerry O'Connor",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "109 West",
    "phone": "9160-07-01 00:00:00",
    "email": "Rep.O'Connor@legis.wisconsin.gov",
    "staff": "Casey Bryant, Henry Dern",
    "committees": []
  },
  {
    "name": "Sylvia Ortiz-Velez",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "307 West",
    "phone": "9108-07-01 00:00:00",
    "email": "Rep.Ortiz-Velez@legis.wisconsin.gov",
    "staff": "Magdalena Herrera, Megan Roche",
    "committees": []
  },
  {
    "name": "Lori Palmeri",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "15 North",
    "phone": "9154-07-01 00:00:00",
    "email": "Rep.Palmeri@legis.wisconsin.gov",
    "staff": "Leah Kelm",
    "committees": []
  },
  {
    "name": "William Penterman",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "207 North",
    "phone": "9138-07-01 00:00:00",
    "email": "Rep.Penterman@legis.wisconsin.gov",
    "staff": "Charlie Fahey, Kathryn Heitman",
    "committees": []
  },
  {
    "name": "Kevin Petersen",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "309 North",
    "phone": "9157-07-01 00:00:00",
    "email": "Rep.Petersen@legis.wisconsin.gov",
    "staff": "BJ Dernbach, Deborah Bowers, Jim Bowers",
    "committees": []
  },
  {
    "name": "Christian Phelps",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "126 North",
    "phone": "9193-07-01 00:00:00",
    "email": "Rep.Phelps@legis.wisconsin.gov",
    "staff": "MGR Govindarajan",
    "committees": []
  },
  {
    "name": "Jim Piwowarczyk",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "412 North",
    "phone": "9798-07-01 00:00:00",
    "email": "Rep.Piwowarczyk@legis.wisconsin.gov",
    "staff": "Samantha Dannhauser",
    "committees": []
  },
  {
    "name": "Priscilla Prado",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "5 North",
    "phone": "9109-07-01 00:00:00",
    "email": "Rep.Prado@legis.wisconsin.gov",
    "staff": "Brooke Smith",
    "committees": []
  },
  {
    "name": "Treig Pronschinske",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "103 West",
    "phone": "9129-07-01 00:00:00",
    "email": "Rep.Pronschinske@legis.wisconsin.gov",
    "staff": "Ilya Maro",
    "committees": []
  },
  {
    "name": "Amaad Rivera-Wagner",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "18 West",
    "phone": "9190-07-01 00:00:00",
    "email": "Rep.Rivera-Wagner@legis.wisconsin.gov",
    "staff": "Steven Gillitzer-Brown",
    "committees": []
  },
  {
    "name": "Jessie Rodriguez",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "306 East",
    "phone": "9121-07-01 00:00:00",
    "email": "Rep.Rodriguez@legis.wisconsin.gov",
    "staff": "Mathew Jansen, Kaitlyn Wender",
    "committees": []
  },
  {
    "name": "Ann Roe",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "320 West",
    "phone": "9144-07-01 00:00:00",
    "email": "Rep.Roe@legis.wisconsin.gov",
    "staff": "Owen Templeton",
    "committees": []
  },
  {
    "name": "Joel Sheehan",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "20 North",
    "phone": "9126-07-01 00:00:00",
    "email": "Rep.Sheehan@legis.wisconsin.gov",
    "staff": "John Dienger",
    "committees": []
  },
  {
    "name": "Christine Sinicki",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "114 North",
    "phone": "9120-07-01 00:00:00",
    "email": "Rep.Sinicki@legis.wisconsin.gov",
    "staff": "Mary Beth George, Dylan Green",
    "committees": []
  },
  {
    "name": "Lee Snodgrass",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "120 North",
    "phone": "9152-07-01 00:00:00",
    "email": "Rep.Snodgrass@legis.wisconsin.gov",
    "staff": "Fawn George, Lauren Yoder",
    "committees": []
  },
  {
    "name": "Patrick Snyder",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "307 North",
    "phone": "9185-07-01 00:00:00",
    "email": "Rep.Snyder@legis.wisconsin.gov",
    "staff": "Sam Hope, Scott Poole",
    "committees": []
  },
  {
    "name": "Shae Sortwell",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "214 North",
    "phone": "9102-07-01 00:00:00",
    "email": "Rep.Sortwell@legis.wisconsin.gov",
    "staff": "Connie Lewis, Zach Pfaffenbach",
    "committees": []
  },
  {
    "name": "Ryan Spaude",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "17 West",
    "phone": "9189-07-01 00:00:00",
    "email": "Rep.Spaude@legis.wisconsin.gov",
    "staff": "Reece Maccaux",
    "committees": []
  },
  {
    "name": "John Spiros",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "212 North",
    "phone": "9186-07-01 00:00:00",
    "email": "Rep.Spiros@legis.wisconsin.gov",
    "staff": "Suzy Geroux, Parker Velte",
    "committees": []
  },
  {
    "name": "David Steffen",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "323 North",
    "phone": "9104-07-01 00:00:00",
    "email": "Rep.Steffen@legis.wisconsin.gov",
    "staff": "Michael Happel, Nicole Walentowski-Domokos",
    "committees": []
  },
  {
    "name": "Angela Stroud",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "9 West",
    "phone": "9173-07-01 00:00:00",
    "email": "Rep.Stroud@legis.wisconsin.gov",
    "staff": "Lucio De Los Santos",
    "committees": []
  },
  {
    "name": "Shelia Stubbs",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "7 North",
    "phone": "9178-07-01 00:00:00",
    "email": "Rep.Stubbs@legis.wisconsin.gov",
    "staff": "Danesha Bonds, Grace Johnson",
    "committees": []
  },
  {
    "name": "Lisa Subeck",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "113 North",
    "phone": "9179-07-01 00:00:00",
    "email": "Rep.Subeck@legis.wisconsin.gov",
    "staff": "Jeanine Schneider, Alex Johnson, Samuel Runta",
    "committees": []
  },
  {
    "name": "Robert Summerfield",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "119 West",
    "phone": "9168-07-01 00:00:00",
    "email": "Rep.Summerfield@legis.wisconsin.gov",
    "staff": "James Mietus, Alex Maro",
    "committees": []
  },
  {
    "name": "Rob Swearingen",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "123 West",
    "phone": "9134-07-01 00:00:00",
    "email": "Rep.Swearingen@legis.wisconsin.gov",
    "staff": "",
    "committees": []
  },
  {
    "name": "Sequanna Taylor",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "16 West",
    "phone": "9111-07-01 00:00:00",
    "email": "Rep.Taylor@legis.wisconsin.gov",
    "staff": "Keshawn Williams",
    "committees": []
  },
  {
    "name": "Angelito Tenorio",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "11 North",
    "phone": "9114-07-01 00:00:00",
    "email": "Rep.Tenorio@legis.wisconsin.gov",
    "staff": "Juliana Bennett",
    "committees": []
  },
  {
    "name": "Paul Tittl",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "218 North",
    "phone": "9125-07-01 00:00:00",
    "email": "Rep.Tittl@legis.wisconsin.gov",
    "staff": "Steve Hall, Andrew LaLonde",
    "committees": []
  },
  {
    "name": "Travis Tranel",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "302 North",
    "phone": "9149-07-01 00:00:00",
    "email": "Rep.Tranel@legis.wisconsin.gov",
    "staff": "Jeff Curry, Zach Oswald",
    "committees": []
  },
  {
    "name": "Duke Tucker",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "418 North",
    "phone": "9175-07-01 00:00:00",
    "email": "Rep.Tucker@legis.wisconsin.gov",
    "staff": "Craig Arrowood",
    "committees": []
  },
  {
    "name": "Ron Tusler",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "22 West",
    "phone": "9103-07-01 00:00:00",
    "email": "Rep.Tusler@legis.wisconsin.gov",
    "staff": "Joseph Romenesko, Nick Schultz",
    "committees": []
  },
  {
    "name": "Randy Udell",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "19 North",
    "phone": "9147-07-01 00:00:00",
    "email": "Rep.Udell@legis.wisconsin.gov",
    "staff": "John Cramer",
    "committees": []
  },
  {
    "name": "Nancy VanderMeer",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "13 West",
    "phone": "9170-07-01 00:00:00",
    "email": "Rep.VanderMeer@legis.wisconsin.gov",
    "staff": "Mallory Green, Jesse Johnson",
    "committees": []
  },
  {
    "name": "Robyn Vining",
    "chamber": "Assembly",
    "party": "Democrat",
    "office": "104 North",
    "phone": "9113-07-01 00:00:00",
    "email": "Rep.Vining@legis.wisconsin.gov",
    "staff": "Bryce Dille, Inez Mendez",
    "committees": []
  },
  {
    "name": "Robin Vos",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "217 West",
    "phone": "9133-07-01 00:00:00",
    "email": "Rep.Vos@legis.wisconsin.gov",
    "staff": "Jenny Toftness, Taylor Corkran, Tyler Ellisen, Mac Feehan, Joseph Knilans, Moriah Krogstad, Jake Wolf",
    "committees": []
  },
  {
    "name": "Chuck Wichgers",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "306 North",
    "phone": "9184-07-01 00:00:00",
    "email": "Rep.Wichgers@legis.wisconsin.gov",
    "staff": "Janel Brandtjen, Rebecca Sande",
    "committees": []
  },
  {
    "name": "Robert Wittke",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "129 West",
    "phone": "9163-07-01 00:00:00",
    "email": "Rep.Wittke@legis.wisconsin.gov",
    "staff": "Terri Griffiths, John Reinemann",
    "committees": []
  },
  {
    "name": "Shannon Zimmerman",
    "chamber": "Assembly",
    "party": "Republican",
    "office": "324 East",
    "phone": "9130-07-01 00:00:00",
    "email": "Rep.Zimmerman@legis.wisconsin.gov",
    "staff": "Christine Fugelseth, John Graber",
    "committees": []
  }
];


export default function LegislatorLookup() {
  const [step, setStep] = useState(1);
  const [chamber, setChamber] = useState(null);
  const [party, setParty] = useState(null);
  const [initial, setInitial] = useState(null);
  const [committee, setCommittee] = useState(null);

  const allCommittees = Array.from(new Set(data.flatMap(l => l.committees))).sort();

  const filteredByChamberParty = data.filter(l => 
    (!chamber || l.chamber === chamber) &&
    (!party || l.party === party)
  );

  const availableInitials = Array.from(new Set(
    filteredByChamberParty.map(l => l.name.split(" ").slice(-1)[0][0])
  )).sort();

  const filtered = filteredByChamberParty.filter(l => 
    (!initial || l.name.split(" ").slice(-1)[0].startsWith(initial)) &&
    (!committee || l.committees.includes(committee))
  );

  return (
    <div style={{ padding: "1rem", maxWidth: "600px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: "bold" }}>Find a WI Legislator</h1>

      {step === 1 && (
        <div>
          <p>Which chamber?</p>
          <button onClick={() => { setChamber("Senate"); setStep(2); }}>Senate</button>{" "}
          <button onClick={() => { setChamber("Assembly"); setStep(2); }}>Assembly</button>
        </div>
      )}

      {step === 2 && (
        <div>
          <p>Which party?</p>
          <button onClick={() => { setParty("Republican"); setStep(3); }}>Republican</button>{" "}
          <button onClick={() => { setParty("Democrat"); setStep(3); }}>Democrat</button>
        </div>
      )}

      {step === 3 && (
        <div>
          <p>Choose the first letter of their last name:</p>
          {availableInitials.map((letter, idx) => (
            <button key={idx} onClick={() => { setInitial(letter); setStep(4); }} style={{ margin: "0.25rem" }}>
              {letter}
            </button>
          ))}
        </div>
      )}

      {step === 4 && (
        <div>
          <p>Filter by committee? (Optional)</p>
          <div style={{ marginBottom: "1rem" }}>
            {allCommittees.map((c, idx) => (
              <button key={idx} onClick={() => setCommittee(c)} style={{ margin: "0.25rem" }}>
                {c}
              </button>
            ))}
            <button onClick={() => setCommittee(null)}>Clear</button>
          </div>

          <p>Matching legislators:</p>
          {filtered.map((leg, idx) => (
            <div key={idx} style={{ border: "1px solid #ccc", padding: "0.75rem", marginBottom: "0.75rem", borderRadius: "0.5rem" }}>
              <p><strong>{leg.name}</strong></p>
              <p>📍 {leg.office}</p>
              <p>📞 {leg.phone}</p>
              <p>✉️ <a href={`mailto:${leg.email}`}>{leg.email}</a></p>
              <p>👥 Staff: {leg.staff}</p>
              <p>🧾 Committees: {leg.committees.join(", ")}</p>
            </div>
          ))}

          <button onClick={() => {
            setStep(1);
            setChamber(null);
            setParty(null);
            setInitial(null);
            setCommittee(null);
          }}>
            Start Over
          </button>
        </div>
      )}
    </div>
  );
}
